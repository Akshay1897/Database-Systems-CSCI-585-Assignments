import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class Spiro {
	public static void main(String args[]) {
		double R = 5.0/1000;
		double r = 1.0/1000;
		double a = 4.0/1000;
		try {
			PrintStream out = new PrintStream(new FileOutputStream("Points.txt"));
			for(double t = 0.00; t < 16 * Math.PI; t = t + 0.001){
				double x = (R + r) * Math.cos((r / R) * t) - a * Math.cos((1 + r / R) * t) -118.285399; 
				double y = (R + r) * Math.sin((r / R) * t) - a * Math.sin((1 + r / R) * t) + 34.020920; 
				out.println(x +"," + y +"," + 0+"");
			}
			out.close();
		 }catch (FileNotFoundException e) {
	      		e.printStackTrace();
	    }
	}
}